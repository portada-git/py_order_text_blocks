# py_portada_order_text_block

([Read in Spanish](README-es.md))

OCR ... [TO DO]


